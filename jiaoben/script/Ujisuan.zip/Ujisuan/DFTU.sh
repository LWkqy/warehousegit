#!/bin/bash
#calculation for band and dos
cp INCAR_ULR INCAR
 mpirun -np 32 vasp >> log
cp CONTCAR POSCAR
rm WAVECAR

#U+dos
mkdir dos
cp * dos
cd dos
cp INCAR_UDOS INCAR
mpirun -np 32 vasp

#U+BAND
mkdir band
cp * band
cd band
cp INCAR_UBAND INCAR
cp KPATH.in KPOINTS
mpirun -np 32 vasp


#chuli
echo -e "21\n211\n1" |vaspkit




#cp INCAR_EC INCAR
#vaspkit -task 201
#bash elasticvaspkit.sh

